from .getGenusType import get_tree_type
