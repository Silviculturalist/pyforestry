import os

# Provide access to the climate shapefile
climate_shapefile_path = os.path.join(os.path.dirname(__file__), "RT_Dlanskod.shp")
