import os

# Provide access to the climate shapefile
climate_shapefile_path = os.path.join(os.path.dirname(__file__), "SwedishCoastLine_NE_medium_clipped.shp")
