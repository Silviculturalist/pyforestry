This package is currently under *very early* development.
Use at your own risk. 

Any corrections, comments, suggestions are greatly appreciated.

Carl Vigren 2024-12-18

